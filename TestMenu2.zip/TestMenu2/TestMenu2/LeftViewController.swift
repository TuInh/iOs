//
//  LeftViewController.swift
//  TestMenu2
//
//  Created by Le Thi Van Anh on 9/19/16.
//  Copyright © 2016 Le Thi Van Anh. All rights reserved.
//

import UIKit
enum LeftMenu: Int{
    case Main = 0
    case Notification
    case Deliverprocess
    case Contacts
    case Mail
    case Logout
}
protocol LeftMenuProtocol {
    func changeViewController(menu: LeftMenu)
}
class LeftViewController: UIViewController, LeftMenuProtocol {

    @IBOutlet weak var tableView: UITableView!
    var menus = ["Main", "Notification", "Deliverprocess", "Contacts", "Mail", "Logout"]
    var iconMainEnable, iconNotificationEnable, iconDeliverprocessEnable, iconContactsEnable, iconMailEnable, iconLogoutEnable  : UIImage!
    var iconMainDisable, iconNotificationDisable, iconDeliverprocessDisable, iconContactsDisable, iconMailDisable, iconLogoutDisable  : UIImage!
    var iconEnables, iconDisables :NSMutableArray!
    
    var mainViewController: UIViewController!
    var notificationViewController : UIViewController!
    var deliverprocessViewController : UIViewController!
    var contactsViewController : UIViewController!
    var mailViewController : UIViewController!
    var logoutViewController : UIViewController!
    var imageHeaderView: ImageHeaderView!
    var selectedPath:NSIndexPath!
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let notificationViewController = storyboard.instantiateViewControllerWithIdentifier("NotificationViewController") as! NotificationViewController
        self.notificationViewController = UINavigationController(rootViewController: notificationViewController)
        
        let deliverprocessViewController = storyboard.instantiateViewControllerWithIdentifier("DeliverProcessViewController") as! DeliverProcessViewController
        self.deliverprocessViewController = UINavigationController(rootViewController: deliverprocessViewController)
        
        let contactsViewController = storyboard.instantiateViewControllerWithIdentifier("ContactsViewController") as! ContactsViewController
        self.contactsViewController = UINavigationController(rootViewController: contactsViewController)
        
        let mailViewController = storyboard.instantiateViewControllerWithIdentifier("MailContributeViewController") as! MailContributeViewController
        self.mailViewController = UINavigationController(rootViewController: mailViewController)
        
        let logoutViewController = storyboard.instantiateViewControllerWithIdentifier("LoginViewController") as! LoginViewController
        self.logoutViewController = UINavigationController(rootViewController: logoutViewController)
        self.tableView.registerCellNib(MenuTableViewCell.self)
        self.tableView.alwaysBounceVertical = false
        self.imageHeaderView = ImageHeaderView.loadNib()
        self.view.addSubview(self.imageHeaderView)
        // Create icon menu for listview
        // icon for disable status
        iconMainDisable = changeImageColor(UIImage(named: "car")!, newColor: UIColor(red: 115.0/255, green: 115.0/255.0, blue: 115.0/255.0, alpha: 1.0))
        iconNotificationDisable = changeImageColor(UIImage(named: "notification")!, newColor: UIColor(red: 115.0/255, green: 115.0/255.0, blue: 115.0/255.0, alpha: 1.0))
        iconDeliverprocessDisable = changeImageColor(UIImage(named: "notification")!, newColor: UIColor(red: 115.0/255, green: 115.0/255.0, blue: 115.0/255.0, alpha: 1.0))
        iconContactsDisable = changeImageColor(UIImage(named: "contact")!, newColor: UIColor(red: 115.0/255, green: 115.0/255.0, blue: 115.0/255.0, alpha: 1.0))
        iconMailDisable = changeImageColor(UIImage(named: "email")!, newColor: UIColor(red: 115.0/255, green: 115.0/255.0, blue: 115.0/255.0, alpha: 1.0))
        iconLogoutDisable = changeImageColor(UIImage(named: "logout")!, newColor: UIColor(red: 115.0/255, green: 115.0/255.0, blue: 115.0/255.0, alpha: 1.0))
        iconDisables = NSMutableArray(array: [iconMainDisable,iconNotificationDisable, iconDeliverprocessDisable,iconContactsDisable, iconMailDisable,iconLogoutDisable])
        // enable  iconMainEnable
        iconMainEnable = changeImageColor(UIImage(named: "car")!, newColor: UIColor(red: 252.0/255, green: 192.0/255.0, blue: 18.0/255.0, alpha: 1.0))
        iconNotificationEnable = changeImageColor(UIImage(named: "logout")!, newColor: UIColor(red: 252.0/255, green: 192.0/255.0, blue: 18.0/255.0, alpha: 1.0))
        iconDeliverprocessEnable = changeImageColor(UIImage(named: "logout")!, newColor: UIColor(red: 252.0/255, green: 192.0/255.0, blue: 18.0/255.0, alpha: 1.0))
        iconContactsEnable = changeImageColor(UIImage(named: "contact")!, newColor: UIColor(red: 252.0/255, green: 192.0/255.0, blue: 18.0/255.0, alpha: 1.0))
        iconMailEnable = changeImageColor(UIImage(named: "email")!, newColor: UIColor(red: 252.0/255, green: 192.0/255.0, blue: 18.0/255.0, alpha: 1.0))
        iconLogoutEnable = changeImageColor(UIImage(named: "logout")!, newColor: UIColor(red: 252.0/255, green: 192.0/255.0, blue: 18.0/255.0, alpha: 1.0))
        iconEnables = NSMutableArray(array: [iconMainEnable, iconNotificationEnable, iconDeliverprocessEnable, iconContactsEnable, iconMailEnable, iconLogoutEnable])
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        self.imageHeaderView.frame = CGRect(x: 0, y: 0, width: self.view.frame.width, height: 160)
        self.view.layoutIfNeeded()
    }
    func changeImageColor(image: UIImage, newColor: UIColor)-> UIImage {
        let rect = CGRectMake(0, 0, image.size.width, image.size.height);
        UIGraphicsBeginImageContext(rect.size);
        let context = UIGraphicsGetCurrentContext();
        CGContextClipToMask(context, rect, image.CGImage);
        CGContextSetFillColorWithColor(context, newColor.CGColor);
        CGContextFillRect(context, rect);
        let imgConverted = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
        let flippedImage = UIImage(CGImage: imgConverted.CGImage!, scale: 1.0, orientation: .DownMirrored)
        return flippedImage
    }
    func changeViewController(menu: LeftMenu) {
        switch menu {
        case .Main:
            self.slideMenuController()?.changeMainViewController(self.mainViewController, close: true)
        case .Notification:
            self.slideMenuController()?.changeMainViewController(self.notificationViewController, close: true)
        case .Deliverprocess:
            self.slideMenuController()?.changeMainViewController(self.deliverprocessViewController, close: true)
        case .Contacts:
            self.slideMenuController()?.changeMainViewController(self.contactsViewController, close: true)
        case .Mail:
            self.slideMenuController()?.changeMainViewController(self.mailViewController, close: true)
        case .Logout:
            self.slideMenuController()?.changeMainViewController(self.logoutViewController, close: true)
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
extension LeftViewController : UITableViewDelegate {
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        if let menu = LeftMenu(rawValue: indexPath.item) {
            switch menu {
            case .Main, .Notification, .Deliverprocess, .Contacts, .Mail, .Logout:
                return 50
            }
        }
        return 0
    }
}

extension LeftViewController : UITableViewDataSource {
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return menus.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        if let menu = LeftMenu(rawValue: indexPath.item) {
            switch menu {
            case .Main, .Notification, .Deliverprocess, .Contacts, .Mail, .Logout:
                let cell = self.tableView.dequeueReusableCellWithIdentifier("MenuTableViewCell") as! MenuTableViewCell
                let data = MenuTableViewCellData(image:(iconDisables.objectAtIndex(indexPath.row)) as! UIImage , text: menus[indexPath.row])
                cell.setData(data)
                if selectedPath != nil {
                    tableView.selectRowAtIndexPath(indexPath, animated: false, scrollPosition: .None)
                    if indexPath.row == selectedPath.row {
                        cell.setCellSelected(iconEnables[indexPath.row] as! UIImage)
                    } else {
                        cell.setCellDeselected(iconDisables[indexPath.row] as! UIImage)
                    }

                }
                
                return cell
            }
        }
        return UITableViewCell()
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        let indexPaths:[NSIndexPath]!
        if (selectedPath != nil) {
            indexPaths = [selectedPath, indexPath]
        } else {
            indexPaths = [indexPath]
        }
        selectedPath = indexPath
        tableView.reloadRowsAtIndexPaths(indexPaths , withRowAnimation: .None)
        if let menu = LeftMenu(rawValue: indexPath.item) {
            self.changeViewController(menu)
        }
    }
    
}

