//
//  ImageHeaderView.swift
//  TestMenu2
//
//  Created by Le Thi Van Anh on 9/19/16.
//  Copyright © 2016 Le Thi Van Anh. All rights reserved.
//

import UIKit

class ImageHeaderView: UIView {

    override func awakeFromNib() {
        super.awakeFromNib()
        
    }
    /*
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func drawRect(rect: CGRect) {
        // Drawing code
    }
    */

}
