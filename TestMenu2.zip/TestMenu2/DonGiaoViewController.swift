//
//  DonGiaoViewController.swift
//  TestMenu2
//
//  Created by Le Thi Van Anh on 9/22/16.
//  Copyright © 2016 Le Thi Van Anh. All rights reserved.
//

import UIKit

class DonGiaoViewController: UIViewController {
    
    @IBOutlet weak var dongiaoTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        dongiaoTableView.registerCellNib(BillTableViewCell.self)
        self.dongiaoTableView.delegate = self
        self.dongiaoTableView.dataSource = self
        
        self.dongiaoTableView.rowHeight = UITableViewAutomaticDimension
        self.dongiaoTableView.estimatedRowHeight = 150
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
extension DonGiaoViewController : UITableViewDelegate {
    
}
extension DonGiaoViewController: UITableViewDataSource {
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 12
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = self.dongiaoTableView.dequeueReusableCellWithIdentifier("BillTableViewCell") as! BillTableViewCell
        return cell;
    }
}
