//
//  BillTableViewCell.swift
//  TestMenu2
//
//  Created by Le Thi Van Anh on 9/23/16.
//  Copyright © 2016 Le Thi Van Anh. All rights reserved.
//

import UIKit

class BillTableViewCell: UITableViewCell {

    @IBOutlet weak var madonLabel: UILabel!
    @IBOutlet weak var nguoiguiLabel: UILabel!
    @IBOutlet weak var sodienthoaiLabel: UILabel!
    @IBOutlet weak var nguoinhanLabel: UILabel!
    @IBOutlet weak var mapLabel: UILabel!
    @IBOutlet weak var ghichuLabel: UILabel!
    @IBOutlet weak var thuhoLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        madonLabel.text = "01699919538"
        nguoiguiLabel.text = randomStringWithLength(140) as String
        // Initialization code
        setupCell()
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
       
        // Configure the view for the selected state
    }
    func setupCell() {
        madonLabel.font = UIFont.preferredFontForTextStyle(UIFontTextStyleBody)
        madonLabel.font = UIFont.boldSystemFontOfSize(madonLabel.font.pointSize)
        var attributeMadon
        NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:str];
        
        // Add attribute NSUnderlineStyleAttributeName
        [attributedString addAttribute:NSUnderlineStyleAttributeName value:[NSNumber numberWithInt:NSUnderlineStyleSingle] range:NSMakeRange(6, 9)];
        
    }
    func randomStringWithLength (len : Int) -> NSString {
        
        let letters : NSString = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
        
        var randomString : NSMutableString = NSMutableString(capacity: len)
        
        for (var i=0; i < len; i++){
            var length = UInt32 (letters.length)
            var rand = arc4random_uniform(length)
            randomString.appendFormat("%C", letters.characterAtIndex(Int(rand)))
        }
        
        return randomString
    }

    
}
