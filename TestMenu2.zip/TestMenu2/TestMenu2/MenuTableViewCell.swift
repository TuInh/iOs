//
//  MenuTableViewCell.swift
//  TestMenu2
//
//  Created by Le Thi Van Anh on 9/20/16.
//  Copyright © 2016 Le Thi Van Anh. All rights reserved.
//

import UIKit
struct MenuTableViewCellData {
    init(image: UIImage, text: String) {
        self.image = image
        self.text = text
    }
    var image: UIImage
    var text: String
}
public class MenuTableViewCell: UITableViewCell {

    @IBOutlet weak var iconMenu: UIImageView!
    @IBOutlet weak var typeMenuLabel: UILabel!
    
    override public func awakeFromNib() {
        super.awakeFromNib()
        self.backgroundColor = UIColor.whiteColor()
        typeMenuLabel.textColor = UIColor.blackColor()
        typeMenuLabel.font = UIFont.preferredFontForTextStyle(UIFontTextStyleTitle3)
        typeMenuLabel.font = UIFont.systemFontOfSize(typeMenuLabel.font.pointSize/1.4)
        iconMenu.contentMode = UIViewContentMode.ScaleAspectFit
        //iconMenu.backgroundColor = UIColor.blackColor()
    }

    override public func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    public func setData(data: Any?) {
        if let data = data as? MenuTableViewCellData {
            self.iconMenu.image = data.image
            self.typeMenuLabel.text = data.text
        }
    }
    public func setCellSelected(selectedImage: UIImage) {
        self.iconMenu.image = selectedImage
       self.typeMenuLabel.textColor = UIColor(red: 252.0/255, green: 192.0/255.0, blue: 18.0/255.0, alpha: 1.0)
    }
    public func setCellDeselected(selectedImage: UIImage) {
        self.iconMenu.image = selectedImage
        self.typeMenuLabel.textColor = UIColor.blackColor()
    }
    func changeImageColor(image: UIImage, newColor: UIColor)-> UIImage {
        let rect = CGRectMake(0, 0, image.size.width, image.size.height);
        UIGraphicsBeginImageContext(rect.size);
        let context = UIGraphicsGetCurrentContext();
        CGContextClipToMask(context, rect, image.CGImage);
        CGContextSetFillColorWithColor(context, newColor.CGColor);
        CGContextFillRect(context, rect);
        let imgConverted = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
        let flippedImage = UIImage(CGImage: imgConverted.CGImage!, scale: 1.0, orientation: .DownMirrored)
        return flippedImage
    }
  
    
    
    
}
